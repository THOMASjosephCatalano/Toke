// Copyright (c) 2018 altusnet
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef TOKE_NOUI_H
#define TOKE_NOUI_H

extern void noui_connect();

#endif // TOKE_NOUI_H
