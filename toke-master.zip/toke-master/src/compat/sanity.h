// Copyright (c) 2018 altusnet
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef TOKE_COMPAT_SANITY_H
#define TOKE_COMPAT_SANITY_H

bool glibc_sanity_test();
bool glibcxx_sanity_test();

#endif // TOKE_COMPAT_SANITY_H
